Fictional visit records for a test fixture.
